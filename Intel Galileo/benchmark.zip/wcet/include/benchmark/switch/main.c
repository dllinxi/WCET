#include "switch.h"
#define COM1_BASE 0x3F8
#define COM2_BASE 0x2F8
#define COM3_BASE 0x3E8
#define COM4_BASE 0x2E8

#define COM1_IRQ 4
#define COM2_IRQ 3
#define COM3_IRQ 4
#define COM4_IRQ 3
#define RX_FIFO 0
#define TX_FIFO 0

#define COM_TX_FIFO ((short int)(COM1_BASE + TX_FIFO))

static inline void outb(short int port, char val) {
    __asm volatile ( "outb %0, %1" : : "a"(val), "d"(port) );
}

void main(){
  //com口输出开始信号
  outb(COM_TX_FIFO, 'S');
  outb(COM_TX_FIFO, 'T');
  switchcase();
  //com口输出结束信号
  outb(COM_TX_FIFO, 'E');
  outb(COM_TX_FIFO, 'D');
}

