/*
  cycle.h
  Benchmark实验对象程序
  
*/
#ifndef  FORCYCLE_H
#define  FORCYCLE_H
/**
  ifndef的作用是假设两个文件同时include 了这个文件，这两个文件如果一个先编译了，那么FORCYCLE_H就被定义了，当编译到第二个文件时，那么在开始的判断ifnef就会自动跳出cycle.h的这个文件的重复编译，这样避免了重复编译.
*/
/**
 被测目标函数
 该函数是wcet分析的目标对象，所得WCET路径是该对函数的路径
*/
/**
  此函数的功能是for型循环，三重for型循环*/
void cycle(){
  int cow=10;
  int colm=10;
  int sum=0;
  for (int i=0;i<cow;i++){
          sum+=i;
   for (int j=0;j<colm;j++){
          sum+=j*j;
     for(int m=0;m<20;m++){
          sum+=m*(m+1);
}
}
}
}
#endif
