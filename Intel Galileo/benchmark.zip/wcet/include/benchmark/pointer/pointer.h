/*
 pointer.h
  Benchmark实验对象程序
  
*/
#ifndef  POINTER_H
#define  POINTER_H
/**
  ifndef的作用是假设两个文件同时include 了这个文件，这两个文件如果一个先编译了，那么POINTER_H就被定义了，当编译到第二个文件时，那么在开始的判断ifnef就会自动跳出pointer.h的这个文件的重复编译，这样避免了重复编译.
*/
/**
 被测目标函数
 该函数是wcet分析的目标对象，所得WCET路径是该对函数的路径
*/
/**
  此函数的功能是用指针进行运算，分别用指针进行加减乘的运算*/
void pointer(){
int a = 6, b = 8, c = 10;
	int add, sub, multiply;
	int *p, *q, *l;
	p = &a;
	q = &b;
	l = &c;
	add = *p + *q;
	sub = *p - *l;
	multiply = *q * *l;
}
#endif
