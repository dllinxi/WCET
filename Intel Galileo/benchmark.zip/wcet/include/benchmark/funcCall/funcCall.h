/*
  funcCall.h
  Benchmark实验对象程序
  
*/
#ifndef  funcCall_H
#define  funcCall_H
/**
  ifndef的作用是假设两个文件同时include 了这个文件，这两个文件如果一个先编译了，那么funcCall_H就被定义了，当编译到第二个文件时，那么在开始的判断ifnef就会自动跳出funcCall.h的这个文件的重复编译，这样避免了重复编译.
*/
/**
 被测目标函数
 该函数是wcet分析的目标对象，所得WCET路径是该对函数的路径
*/
/**
  此函数的功能是多个函数调用，两个数的加，减，乘*/
int Add(int a, int b)
{
	int c = 0;
	c = a + b;
	return c;
}

int Sub(int a, int b)
{
	int c = 0;
	c = a - b;
	return c;
}

int Multiply(int a, int b)
{
	int c = 0;
	c = a*b;
	return c;
}
void funcCall(){
int a = 10, b = 20;
	int sum , sub ,multiply;
	sum=Add(a, b);
	sub=Sub(a, b);
	multiply=Multiply(a, b);

}
#endif
