/*
  ifelse.h
  Benchmark实验对象程序
  
*/
#ifndef  IFELSE_H
#define  IFELSE_H
/**
  ifndef的作用是假设两个文件同时include 了这个文件，这两个文件如果一个先编译了，那么IFELSE_H就被定义了，当编译到第二个文件时，那么在开始的判断ifnef就会自动跳出ifelse.h的这个文件的重复编译，这样避免了重复编译.
*/
/**
 被测目标函数
 该函数是wcet分析的目标对象，所得WCET路径是该对函数的路径
*/
/**
  此函数的功能是判断输入的年份，月份，日期是否合法，以2000年的2月29为例*/

void ifelse(){
int year=2000,leap;
  int month=2;
  int day=29;
  if(month==1||month==3||month==5||month==7||month==8||month==10||month==12)
    {
        if(day>0&&day<32)
        {
            leap=1;
        }
        else 
            leap=0;
    }
    else if(month==2)
    {
        if((year%4==0&&year%100!=0)||year%400==0)
        {
            if(day>0&&day<30)
                leap=1;
            else 
            leap=0;
        }
        else
        {
            if(day>0&&day<29)
                leap=1;
            else 
            leap=0;
        } 
    }
    else if(month==4||month==6||month==9||month==11)
    {
        if(day>0&&day<31)
            leap=1;
        else 
            leap=0;
    }
    else
        leap=0;
}
#endif
